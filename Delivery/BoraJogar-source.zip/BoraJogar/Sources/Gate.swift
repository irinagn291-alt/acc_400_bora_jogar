import SwiftUI
import CoreLocation
import EventKit
import EventKitUI
import UserNotifications

@main struct k73:App {
 @UIApplicationDelegateAdaptor(vDelegate.self) var delegate
 @StateObject var s = v73()
 var body:some Scene{WindowGroup{n73().environmentObject(s).task{await s.reminders();await s.reconcileLive()}}}
}
final class vDelegate:NSObject,UIApplicationDelegate,UNUserNotificationCenterDelegate {
 func application(_ application:UIApplication,didFinishLaunchingWithOptions launchOptions:[UIApplication.LaunchOptionsKey:Any]? = nil)->Bool {UNUserNotificationCenter.current().delegate = self;return true}
 nonisolated func userNotificationCenter(_ center:UNUserNotificationCenter,willPresent notification:UNNotification) async->UNNotificationPresentationOptions {[.banner,.list,.sound]}
}
struct vCalendar:UIViewControllerRepresentable {
 var game:zM;@Environment(\.dismiss) var dismiss
 func makeCoordinator()->vCalDelegate{vCalDelegate(dismiss)}
 func makeUIViewController(context:Context)->EKEventEditViewController {let c = EKEventEditViewController();let store = EKEventStore();c.eventStore = store;let e = EKEvent(eventStore:store);e.title = game.home+" · "+game.away;e.startDate = game.date;e.endDate = game.date.addingTimeInterval(Double(game.duration)*60);e.location = game.venue;e.notes = zL("Community football organized with Bora Jogar.");c.event = e;c.editViewDelegate = context.coordinator;return c}
 func updateUIViewController(_ c:EKEventEditViewController,context:Context){}
 final class vCalDelegate:NSObject,EKEventEditViewDelegate {var close:DismissAction;init(_ a:DismissAction){close = a};func eventEditViewController(_ controller:EKEventEditViewController,didCompleteWith action:EKEventEditViewAction){close()}}
}
final class vLocation:NSObject,ObservableObject,CLLocationManagerDelegate {
 @Published var point:CLLocation?;@Published var message = ""
 private let service = CLLocationManager()
 override init(){super.init();service.delegate = self;service.desiredAccuracy = kCLLocationAccuracyKilometer}
 func start(){switch service.authorizationStatus{case .authorizedWhenInUse,.authorizedAlways:message = "Finding nearby courts…";service.requestLocation();case .notDetermined:service.requestWhenInUseAuthorization();case .denied,.restricted:message = "Location is unavailable. Search by city instead.";@unknown default:message = "Search by city instead."}}
 func locationManagerDidChangeAuthorization(_ manager:CLLocationManager){if manager.authorizationStatus == .authorizedWhenInUse || manager.authorizationStatus == .authorizedAlways {manager.requestLocation()}else if manager.authorizationStatus == .denied || manager.authorizationStatus == .restricted {message = "Location is unavailable. Search by city instead."}}
 func locationManager(_ manager:CLLocationManager,didUpdateLocations locations:[CLLocation]){point = locations.last;message = "Sorted by approximate distance."}
 func locationManager(_ manager:CLLocationManager,didFailWithError error:Error){message = "Could not find your location. Search by city instead."}
 func distance(_ v:zV,_ here:CLLocation)->Double{CLLocation(latitude:v.lat,longitude:v.lon).distance(from:here)}
}
